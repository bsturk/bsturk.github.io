#!/usr/bin/env python

import os, string
import sys

executable = ''
piece_name = ''
short      = False
DEBUG      = False

#############

def dbg_print( str ):

    if DEBUG:
        print 'DEBUG: ' + str

#############

if len( sys.argv ) == 2:
    piece_name = sys.argv[1]

elif len( sys.argv ) == 3:
    piece_name = sys.argv[1]
    executable = sys.argv[2]

elif len( sys.argv ) == 4:
    piece_name = sys.argv[1]
    executable = sys.argv[2]
    short = True

if piece_name == '':
    print 'No piece specified'
    sys.exit( 0 )

piece_info_raw = []

if executable == '':

    if sys.platform == 'win32':
        piece_info_raw = os.popen( 'dreamblade.exe -P' ).readlines()

    else:
        piece_info_raw = os.popen( './dreamblade -P' ).readlines()

else:
    piece_info_raw = os.popen( executable + ' -P' ).readlines()

piece_infos = []
lines       = []

for l in piece_info_raw:

    l = l.strip()
    dbg_print( l )

    if l == '':     ##  blank line means done with this entry
        piece_infos.append( lines[:] )
        lines = []
        continue

    else:
        lines.append( l )

selected_piece = None
info           = None

for i in piece_infos:

    for ii in i:
        dbg_print( ii )

	dbg_print( 'Checking for match against piece name in database: ' + i[ 0 ] )

    if i[ 0 ].lower() == piece_name.lower():

        selected_piece = piece_name
        info           = i

        dbg_print( 'Found piece ' + piece_name )
        break

if selected_piece is None or info is None:
    print 'Could not find stats for piece ' + piece_name
    sys.exit( 0 )

index       = 1
cost        = ''
stats       = ''
cost_found  = False
stats_found = False
is_location = False

while not cost_found or not stats_found:

    line   = info[ index ]
    index += 1

    if line == 'Location':
        is_location = True
        stats_found = True

    ##  could be -1 for variable so check index 1 too

    if line[ 0 ] in string.digits or line[ 1 ] in string.digits:

        c = string.count( line, '|' ) 

        if c == 0:
            cost_found = True
            cost       = line

        else:
            stats_found = True
            stats       = line

base_cost   = ''
aspect_cost = 0     ## in spawn points
index       = 0

if not short:
    print 'Full cost: ' + cost

    if not is_location:
        tmp = stats.replace( '-1', '*' )
        print 'Stats:     ' + tmp

    for i in range( len( cost ) ):
        if cost[ i ].isalpha():
            aspect_cost += 1

done = False

while not done and index < len( cost ):

    c = cost[ index ]
    index += 1

    if c in string.digits:
        base_cost += c

    else:
        done = True

if not short:
    print 'Base cost: ' + base_cost
    print 'Aspect cost (in generic spawn points): ' + str( aspect_cost )

base_cost_num = float( base_cost )

if not is_location:

    loc_str       = ''
    stat_split    = string.split( stats )
    power         = int( stat_split[ 0 ] )
    split_two     = string.split( stat_split[ 1 ], '|' )
    defense       = int( split_two[ 0 ] )
    life          = int( split_two[ 1 ] )

    ##  Handle variable attributes

    if ( power == -1 ):
        power = 0

    if ( defense == -1 ):
        defense = 0

    if ( life == -1 ):
        life = 0

    ##  My regression
    ## calc_cost     = -1.68 + ( 0.971 * power ) + ( 0.312 * defense ) + ( 0.258 * life )

    ##  These are other formulas I've seen on the web
    #calc_cost     = -1.7875 + ( 0.9878 * power ) + ( 0.3388 * defense ) + ( 0.2538 * life )

    #calc_cost     = -1.86 + ( 1.0 * power ) + ( 0.27 * defense ) + ( 0.33 * life )

    ##
    # Spawn Cost = .03 + .65 * Power + .29 * Defense + .31 * Life
    #calc_cost = .03 + ( 0.65 * power ) + ( 0.29 * defense ) + ( 0.31 * life )

    ##  This one seems to take into account all 6 released sets' stats

    calc_cost = -1.72 + ( 0.97 * power ) + ( 0.32 * defense ) + ( 0.26 * life )

else:
    loc_str = ' (L)'
    calc_cost = 0

print 'Cost for ' + piece_name + loc_str + '\'s abilities is ' + str( base_cost_num - calc_cost ) + ' spawn, ' + str( ( base_cost_num + aspect_cost ) - calc_cost ) + ' spawn + aspect '
