#!/usr/bin/env python

import os, string
import random, sys

###################### CUSTOMIZATION ##########################
######################               ##########################
######################  BE CAREFUL   ##########################
######################    EDITING    ##########################

##  Don't add these pieces to warbands

## infinite combos
## ignore_names     = [ 'Chain Servant', 'Deathwish Guardian', 'Madcap Aristocrat' ]

ignore_names     = []

##  Always add these pieces to warbands first
auto_add_names   = [ 'Lady of the Funeral' ]

##  Include these sets, to limit just create a [ ] with the strings, comma separated.
##
##  i.e. include_sets = [ 'Core', 'Anvilborn' ]
##
##  This will limit pieces to just the Core and Anvilborn sets
##  The same thing can be done w/ aspects and lineages below
##  

daybreak_test    = [ 'Core', 'Daybreak' ]
all_sets         = [ 'Core', 'Baxar\'s War', 'Chrysotic Plague', 'Anvilborn', 'Night Fusion', 'Serrated Dawn', 'Witching Hour', 'Twilight', 'Daybreak', 'Custom' ]
include_sets     = daybreak_test

##  Include these aspects, None is to handle non-aspect pieces, e.g. Anvilborn.

all_aspects      = [ 'None', 'Valor', 'Fear', 'Madness', 'Passion' ]
include_aspects  = all_aspects

##  Limit to these lineages.  None is to handle no lineage since not all pieces have a lineage.

all_lineages     = [ 'None', 'Janus', 'Bloodcut', 'Lost', 'Hiveling', 'Hellbred', 'Stitched', 'Quantum' ]
include_lineages = all_lineages

###################### END CUSTOMIZATION ##########################

executable       = ''
filename         = 'random_warband.txt'

#############

def get_aspects( _spawn_cost_str ):

    aspects = []

    if 'V' in _spawn_cost_str:
        aspects.append( 'Valor' )

    if 'F' in _spawn_cost_str:
        aspects.append( 'Fear' )

    if 'P' in _spawn_cost_str:
        aspects.append( 'Passion' )

    if 'M' in _spawn_cost_str:
        aspects.append( 'Madness' )

    if len( aspects ) == 0:
        aspects = [ 'None' ]

    return aspects

#############

def check_filters( _piece_name ):

    ##  Returns True if filtered out

    if _piece_name in ignore_names:
        return True

    piece_info = piece_infos[ _piece_name ]

    aspects = piece_info[ 0 ]
    lineage = piece_info[ 1 ]
    setn    = piece_info[ 2 ]

    for aspect in aspects:
        if aspect not in include_aspects:
            return True

    if lineage not in include_lineages:
        return True

    if setn not in include_sets:
        return True

    return False

#############

def verify_legal( _name, _cur_names, _warband_count ):

    max_allowed_of_name = 3

	##  TODO: Come up with a generic way to deal whith this

    if _name == 'Killer Bean':

        cur_count = 0

        for n in _cur_names:
            if n == 'Killer Bean':
                cur_count += 1

        if cur_count == 1 or cur_count == 2:

            max_allowed_of_name = 3 + cur_count
            return _warband_count, max_allowed_of_name

        else:
            return _warband_count + 1, max_allowed_of_name

    elif _name == 'Omen Locust':

        cur_count = 0

        for n in _cur_names:
            if n == 'Omen Locust':
                cur_count += 1

        if cur_count == 1 or cur_count == 2:

            max_allowed_of_name = 3 + cur_count
            return _warband_count, max_allowed_of_name

        else:
            return _warband_count + 1, max_allowed_of_name

    elif _name == 'Sybil':

        cur_count = 0

        for n in _cur_names:
            if n == 'Sybil':
                cur_count += 1

        if cur_count == 1:
            max_allowed_of_name = 4
            return _warband_count, max_allowed_of_name

        else:
            return _warband_count + 1, max_allowed_of_name

    elif _name == 'Grand Hive':
        max_allowed_of_name = 1
        return _warband_count + 3, max_allowed_of_name

    else:
        return _warband_count + 1, max_allowed_of_name

#############

if len( sys.argv ) == 2:
    filename   = sys.argv[1]

elif len( sys.argv ) == 3:
    filename   = sys.argv[1]
    executable = sys.argv[2]

piece_info_raw = []

if executable == '':

    if sys.platform == 'win32':
        piece_info_raw = os.popen( 'dreamblade.exe -P' ).readlines()

    elif sys.platform == 'darwin':
        piece_info_raw = os.popen( './dreamblade-osx -P' ).readlines()

    else:
        piece_info_raw = os.popen( '/tmp/dreamblade-dbg -P' ).readlines()

else:
    piece_info_raw = os.popen( executable + ' -P' ).readlines()

piece_infos = {}            ##  name:tuple of relevant info

for i in range( len( piece_info_raw ) ):

    try:

        l = piece_info_raw[ i ]
        l = l.strip()

        if l == '':

            ##  next line is name, DEBUG version it is 'Loading .....' msg

            look_ahead_index = i + 1
            l                = piece_info_raw[ look_ahead_index ]
            l                = l.strip()

            if l[ :7 ] == 'Loading':
                look_ahead_index += 1
                l                 = piece_info_raw[ look_ahead_index ]
                l                 = l.strip()

            piece_name = l
            spawn_cost = ''
            aspect     = 'None'
            lineage    = 'None'
            set        = ''

            ##  next line is either spawn cost or lineage

            look_ahead_index += 1
            l                 = piece_info_raw[ look_ahead_index ]
            l                 = l.strip()

            if l[ 0 ].isdigit():
                spawn_cost = l

            else:

                lineage = l

                look_ahead_index += 1
                l = piece_info_raw[ look_ahead_index ]
                l = l.strip()

                spawn_cost = l

            ##  Set is second to last line before empty line

            found = False

            while not found:

                look_ahead_index += 1
                l = piece_info_raw[ look_ahead_index ]
                l = l.strip()

                if l == '':
                    s = piece_info_raw[ look_ahead_index - 2 ]
                    set = s.strip()
                    found = True

            ## At this point we have all the info we need

            aspects = get_aspects( spawn_cost )

            piece_infos[ piece_name ] = ( aspects, lineage, set )

    except IndexError, e:
        ##  End of output
        pass 

    except Exception, e:
        print 'Got an exception ' + str( e )

if len( piece_infos ) > 0:

    f             = open( filename, 'w' )
    ok            = True
    max_warband   = 16
    warband_count = 0
    names_so_far  = []
    names         = piece_infos.keys()
    
    ##  NOTE: If one of the 3 in verify_legal are added to auto_add_names this won't work

    for n in auto_add_names:
        f.writelines( n + '\n' )
        names_so_far.append( n )

    warband_count = len( names_so_far )

    while ( ok ):

        prev_warband_count = warband_count
        name               = random.choice( names )

        ##  Check for filters

        filtered_out = check_filters( name )

        if filtered_out:
            #print 'Filtered out ' + name
            continue

        ##  Make sure adding it would be legal
        warband_count, max_of_name = verify_legal( name, names_so_far, warband_count )

        if warband_count == max_warband:
            ok = False
        
        if warband_count > max_warband:
            print 'Skipping ' + name + ' as it violates warband selections so far and warband limit'
            warband_count = prev_warband_count

        else:

            count = 0

            for n in names_so_far:
                if n == name:
                    count += 1

            if count < max_of_name:
                f.writelines( name + '\n' )
                names_so_far.append( name )

    f.close()

else:
    print 'No pieces found!'
