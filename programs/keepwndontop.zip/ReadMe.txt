*********************************  KeepWndOnTop ReadMe  *********************************

This program is pretty cut and dry:

* Allows a window to stay in the top of the Z order regardless of what
  other windows are up.  Unlike Nail and Top-It this program doesn't sit
  in the system tray. Instead it integrates with the system menu (activated by either
  clicking the icon in the upper left corner or pressing Alt-space).
  
  I usually hide the taskbar and avoid the mouse at all costs so this was useful for
  me.  Tell me what you think.
  
* Simple to use

* It's free!

** Operating system requirements **

Windows 9x/NT/2000  ( Not tested on Win9x )

That's it.  No support files, installation. 

** Usage **

Run KeepWndOnSpawn.exe directory or by a shortcut in your startup
folder.  Only once instance can be run.

**  Known limitations  **

The system menu for DOS consoles ( cmd.exe, command.com )
are different and the hooks do not work.

I have seen no system degredation by using this program.
It works by installing a system wide hook which according to the
SDK documents could affect performance.  I haven't noticed
*ANY* difference at all on both NT 4 and Win2K.

***  Contact and License Info  ***

This program has no warranty.  
This program is free for non-profit use.
Blah, Blah, BLAH.

Actually it's giftware.  If you like/use/hate the program, I collect old 8 bit (Atari, C64, AppleII)
computer magazines and game company catalogs. Email me if you have anything interesting you're dying
to part with.

If you package this program and distribute it
all I ask is that you let me know about it.

For questions, bug reports, feedback, etc:
bsturk@adelphia.net

Latest version always at:
http://users.adelphia.net/~bsturk
