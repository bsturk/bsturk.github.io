// emu_ini_file.cpp : implementation of the emu_ini_file class
//

#define _MAX_PATH_ 256

#include "emu_ini_file.h"

const int emu_ini_file::NUM_LINES_IN_INI_FILE = 7;

/////////////////////////////////////////////////////////////////////

emu_ini_file::emu_ini_file( const char* pszFileNameQualified )
{
    assert( pszFileNameQualified );

    m_strIniFileName = pszFileNameQualified;
}

/////////////////////////////////////////////////////////////////////

emu_ini_file::~emu_ini_file( void )
{
}

/////////////////////////////////////////////////////////////////////

bool emu_ini_file::parse( void )
{
   FILE* fDatFile = fopen( m_strIniFileName, "r" );

   if ( !fDatFile ) 
   { 
       return false; 
   }

   char token[ _MAX_PATH_ ];

   for ( int i = 1; i <= NUM_LINES_IN_INI_FILE; i++ )  
   {
      bool bRet = read_line_and_tokenize( fDatFile, token );      // token is out param

      if ( NULL == token || false == bRet )
      {
          return false;
      }

      //  These variables are based on positions in the file ( their line # )

      switch ( i ) 
      {
         case 1:    m_strCommandLine    = token;       break;
         case 2:    m_strProgramsPath   = token;       break;
         case 3:    m_strBitmapPath     = token;       break;
         case 4:    m_strEmuName        = token;       break;
         case 5:    m_strDatFileName    = token;       break;
         case 6:    m_cDelimiter        = token[ 0 ];  break;
         case 7:    m_strEmuText        = token;       break;

         default:   return false; 
      }
   }
   
   fclose( fDatFile );

   return true;
}

/////////////////////////////////////////////////////////////////////

bool emu_ini_file::read_line_and_tokenize( FILE* pFP, char* pszToken )
{
   assert( pFP );

   char delimiter[ ] = "#";
   char line     [ _MAX_PATH_ ];

   char* pToken = NULL;

   fgets( line, _MAX_PATH_, pFP );
   
   pToken = strtok( line, delimiter );

   if ( NULL == pToken )
   {
       return false;
   }

   strcpy( pszToken, pToken );

   return true;
}
