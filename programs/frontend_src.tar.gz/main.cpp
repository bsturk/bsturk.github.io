#include <qapplication.h>
#include "frontendwindow.h"


int main( int argc, char** argv )
{
	QApplication app( argc, argv );

	FrontEndWindow window;
	app.setMainWidget(&window);

	window.show();

	return app.exec();
}

