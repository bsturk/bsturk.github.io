// emu_ini_file.h : interface of the emu_ini_file class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined( _EMU_INI_FILE_H_INCLUDED_ )
#define _EMU_INI_FILE_H_INCLUDED_

#include <assert.h>
#include <vector>
#include <qstring.h>
#include <stdio.h>

class emu_ini_file
{

public:

             emu_ini_file( const char * pszFileNameQualified );
	virtual ~emu_ini_file( );

    bool    parse( void );

    QString GetIniFilename                 ( void ) const { return m_strIniFileName; }
    QString GetDatFilename                 ( void ) const { return m_strDatFileName; }

    QString GetEmuName                     ( void ) const { return m_strEmuName; }
    QString GetProgramsPath                ( void ) const { return m_strProgramsPath; }
    QString GetBitmapPath                  ( void ) const { return m_strBitmapPath; }
    QString GetDefaultCommandLine          ( void ) const { return m_strCommandLine; }
    QString GetEmuText                     ( void ) const { return m_strEmuText; }
    char    GetCommandLineFlagDeliminter   ( void ) const { return m_cDelimiter; }

protected:

    // -> THIS MUST CHANGE IF MORE ATTRIBUTES ARE ADDED TO THE FILE

    bool read_line_and_tokenize( FILE* pFP, char* pszToken );

    static const int NUM_LINES_IN_INI_FILE;

    char     m_cDelimiter;

    QString m_strIniFileName;
    QString m_strDatFileName;

    QString m_strEmuName;
    QString m_strProgramsPath;
    QString m_strBitmapPath;
    QString m_strCommandLine;
    QString m_strEmuText;
};

#endif // !defined( _EMU_INI_FILE_H_INCLUDED_ )
