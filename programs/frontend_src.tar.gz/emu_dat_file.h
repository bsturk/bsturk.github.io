// emu_dat_file.h : interface of the CEmuDatFile class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined( _EMU_DAT_FILE_H_INCLUDED_ )
#define _EMU_DAT_FILE_H_INCLUDED_

#include <vector>
#include <qstring.h>
#include <assert.h>
#include <stdio.h>

class emu_dat_file
{

public:

    static const QString USE_DEFAULT_ENTRY_STRING;           //  so clients can compare

    emu_dat_file( const char* pszFileNameQualified );
	virtual ~emu_dat_file( void );

    bool parse( void );
    void GetProgramNames( std::vector< QString >& program_names, bool bSortIt ) const;

    QString GetBinaryFromProgramName            ( QString strProgramName ) const;
    QString GetBitmapFromProgramName            ( QString strProgramName ) const;
    QString GetSpecialCommandArgsFromProgramName( QString strProgramName ) const;
    QString GetTextFromProgramName              ( QString strProgramName ) const;

    static const QString SYMBOLIC_FILE_ID;
    static const QString SYMBOLIC_FILE_ID_W_DELIM;

protected:

    static const QString DELIMITERS;

    static const int BINARY_INDEX;
    static const int BITMAP_INDEX;
    static const int COMMAND_ARG_INDEX;
    static const int TEXT_INDEX;
    static const int PAST_LAST_ENTRY;

    bool ParseLineForName( char* textLine, bool& bComment );
    void SortVector( std::vector< QString >& string_vector ) const;

    QString FindLineWithProgram( QString strProgramName, bool& bSuccess ) const;
    QString GetTokenAtIndex( QString strProgramName, int nIndex ) const;

    QString m_strDatFileName;

    std::vector< QString > PROGRAM_NAMES;
};

#endif // !defined( _EMU_DAT_FILE_H_INCLUDED_ )
