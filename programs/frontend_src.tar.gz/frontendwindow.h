#include "emu_dat_file.h"
#include "emu_ini_file.h"
#include <qmainwindow.h>
#include <unistd.h>

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QGroupBox;
class QLabel;
class QListBox;
class QListBoxItem;
class QPushButton;

class FrontEndWindow : public QMainWindow
{
	Q_OBJECT

public:

	FrontEndWindow( QWidget* parent = 0, const char* name = 0, WFlags f = WType_TopLevel );

public slots:

    void open_emu            ( void );
    void close_emu           ( void );
    void on_launch_emu       ( void );
    void update_prog_controls( void );

protected:

    void reset_control_text( void );

    void parse_cmd_line    ( QString cmd_line, QStringList& tokenized_cmd_line );
    void handle_spawn_error( QString prog_name );

    bool           _config_in_use;
                   
    emu_ini_file*  _ini_file;
    emu_dat_file*  _dat_file;
                   
    QListBox*      _list_box;
    QLabel*        _pixmap;
    QGroupBox*     _emu_box;
    QLabel*        _emu_text;
    QGroupBox*     _prog_box;
    QLabel*        _prog_text;

    QPushButton* _launch_button;
    QPushButton* _open_button;
    QPushButton* _close_button;
};
