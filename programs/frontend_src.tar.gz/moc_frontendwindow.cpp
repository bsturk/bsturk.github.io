/****************************************************************************
** FrontEndWindow meta object code from reading C++ file 'frontendwindow.h'
**
** Created: Sat Jul 7 16:17:58 2001
**      by: The Qt MOC ($Id: qt/src/moc/moc.y   2.3.1   edited 2001-04-23 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "frontendwindow.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *FrontEndWindow::className() const
{
    return "FrontEndWindow";
}

QMetaObject *FrontEndWindow::metaObj = 0;

void FrontEndWindow::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QMainWindow::className(), "QMainWindow") != 0 )
	badSuperclassWarning("FrontEndWindow","QMainWindow");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString FrontEndWindow::tr(const char* s)
{
    return qApp->translate( "FrontEndWindow", s, 0 );
}

QString FrontEndWindow::tr(const char* s, const char * c)
{
    return qApp->translate( "FrontEndWindow", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* FrontEndWindow::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QMainWindow::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (FrontEndWindow::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (FrontEndWindow::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    typedef void (FrontEndWindow::*m1_t2)();
    typedef void (QObject::*om1_t2)();
    typedef void (FrontEndWindow::*m1_t3)();
    typedef void (QObject::*om1_t3)();
    m1_t0 v1_0 = &FrontEndWindow::open_emu;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &FrontEndWindow::close_emu;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &FrontEndWindow::on_launch_emu;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &FrontEndWindow::update_prog_controls;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    QMetaData *slot_tbl = QMetaObject::new_metadata(4);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(4);
    slot_tbl[0].name = "open_emu()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "close_emu()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "on_launch_emu()";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "update_prog_controls()";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"FrontEndWindow", "QMainWindow",
	slot_tbl, 4,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
