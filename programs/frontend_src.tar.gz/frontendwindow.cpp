#include "frontendwindow.h"

#define _MAX_PATH_ 256

#include <qgroupbox.h>
#include <qlabel.h>
#include <qlistbox.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qfiledialog.h>
#include <qmessagebox.h>
#include <qvbox.h>

#define DEFAULT_BITMAP "default.bmp"

#ifdef _WS_WIN_
#include <process.h>			//  _spawnv
#endif

#include <errno.h>

FrontEndWindow::FrontEndWindow( QWidget* parent, const char* name, WFlags f )
	: QMainWindow( parent, name, f )
{
    QPixmap image0( DEFAULT_BITMAP );

    if ( !name )
        setName( "fe_frame" );

    resize( 596, 480 ); 
	setCaption( "FrontEnd" );

    _pixmap = new QLabel( this, "_pixmap" );
    _pixmap->setGeometry( QRect( 258, 4, 331, 262 ) ); 
    _pixmap->setProperty( "pixmap", image0 );
    _pixmap->setProperty( "scaledContents", QVariant( TRUE, 0 ) );
    _pixmap->setMinimumHeight( 262 );
    _pixmap->setMinimumWidth( 331 );

    _emu_box = new QGroupBox( this, "_emulator_box" );
    _emu_box->setGeometry( QRect( 259, 270, 331, 81 ) ); 
    _emu_box->setProperty( "title", tr( "" ) );
    _emu_box->setMinimumHeight( 81 );

    _emu_text = new QLabel( _emu_box, "_emu_text" );
    _emu_text->setGeometry( QRect( 11, 20, 313, 51 ) ); 
    _emu_text->setProperty( "text", tr( "** no emulator config loaded **" ) );
    _emu_text->setProperty( "alignment", int( QLabel::AlignTop | QLabel::AlignLeft ) );

    _prog_box = new QGroupBox( this, "_program_box" );
    _prog_box->setGeometry( QRect( 259, 356, 330, 81 ) ); 
    _prog_box->setProperty( "title", tr( "" ) );
    _prog_box->setMinimumHeight( 81 );

    _prog_text = new QLabel( _prog_box, "_prog_text" );
    _prog_text->setGeometry( QRect( 11, 20, 313, 45 ) ); 
    _prog_text->setProperty( "text", tr( "** no program selected **" ) );
    _prog_text->setProperty( "alignment", int( QLabel::AlignTop | QLabel::AlignLeft ) );

    _open_button = new QPushButton( this, "_open_button" );
    _open_button->setGeometry( QRect( 259, 442, 90, 30 ) ); 
    _open_button->setText( "&Open emu	" );

    _launch_button = new QPushButton( this, "_launch_button" );
    _launch_button->setGeometry( QRect( 353, 442, 142, 30 ) ); 
    _launch_button->setText( "&Launch" );

    _launch_button->setEnabled( false );

    _close_button = new QPushButton( this, "_close_button" );
    _close_button->setGeometry( QRect( 499, 442, 90, 30 ) ); 
    _close_button->setText( "&Close emu" );

    _close_button->setEnabled( false );

    _list_box = new QListBox( this, "_list_box" );
    _list_box->setGeometry( QRect( 4, 4, 245, 467 ) ); 

    // QBoxLayout* hbox_groups  = new QVBoxLayout( ( QWidget* )NULL, 2 );

    QBoxLayout* main       = new QBoxLayout( this, QBoxLayout::LeftToRight, 2 );

    QBoxLayout* hbox_left  = new QHBoxLayout( ( QWidget* )NULL, 2 );
    QBoxLayout* hbox_right = new QHBoxLayout( ( QWidget* )NULL, 2 );

    main->addLayout( hbox_left, 1 );
    main->addLayout( hbox_right, 3 );

    QBoxLayout* vbox_left    = new QVBoxLayout( hbox_left, 2 );
    vbox_left->addWidget( _list_box, 10 );

    QBoxLayout* vbox_right   = new QVBoxLayout( hbox_right, 2 );
    QBoxLayout* hbox_buttons = new QHBoxLayout( ( QWidget* )NULL, 2 );

    vbox_right->addWidget ( _pixmap, 10 );
    vbox_right->addWidget ( _emu_box, 2 );
    vbox_right->addWidget ( _prog_box, 2 );
    vbox_right->addLayout ( hbox_buttons, 0 );

    hbox_buttons->addWidget( _open_button );
    hbox_buttons->addWidget( _launch_button );
    hbox_buttons->addWidget( _close_button );

    _config_in_use = false;

    connect( _open_button, SIGNAL( clicked() ), this, SLOT( open_emu() ) );
    connect( _close_button, SIGNAL( clicked() ), this, SLOT( close_emu() ) );
    connect( _list_box, SIGNAL( selectionChanged() ), this, SLOT( update_prog_controls() ) );
    connect( _launch_button, SIGNAL( clicked() ), this, SLOT( on_launch_emu() ) );
}

/////////////////////////////////////////////////////////////////////

void FrontEndWindow::open_emu( void )
{
    if ( _config_in_use )
    {
        QMessageBox mb ( "FrontEnd:     Close currently opened emulator",
              "Are you sure you want to close the currently opened emulator to open a new one?",
              QMessageBox::Information,
              QMessageBox::Yes | QMessageBox::Default,
              QMessageBox::No | QMessageBox::Escape,
              NULL );

        if ( QMessageBox::No == mb.exec( ) )
        {
            return;
        }
    }

    close_emu( );

    QString s( QFileDialog::getOpenFileName( QString::null, "Frontend ini files (*.ini)", this ) );

    if ( ! s.isEmpty( ) )
    {
        _ini_file = new emu_ini_file( s ); 

        if ( _ini_file->parse( ) )
        {
            _dat_file = new emu_dat_file( _ini_file->GetDatFilename( ) );

            if ( _dat_file->parse( ) )  //  TODO:  Add a sort option
            {
                _emu_box->setTitle ( "Info for " + _ini_file->GetEmuName( ) + " :" ); 
                _emu_text->setText( _ini_file->GetEmuText( ) );

                QString msg;
                msg.sprintf( "&Launch %s", _ini_file->GetEmuName( ).latin1( ) );

                _launch_button->setText( msg );

                std::vector< QString > program_names;

                _dat_file->GetProgramNames( program_names, TRUE );

                int num_entries = program_names.size( );

                for ( int i = 0; i < num_entries; i++ )
                    _list_box->insertItem( program_names[ i ] );

                if ( num_entries > 0 )
                    _list_box->setCurrentItem( 0 );

				_config_in_use = true;

                _close_button->setEnabled ( true );
                _launch_button->setEnabled( true );
            }

            else
            {
                QMessageBox::information( this, "FrontEnd",
                                          "Error parsing emulator data file: check format" );

                delete _ini_file;
                delete _dat_file;

                _ini_file = NULL;
                _dat_file = NULL;

                reset_control_text( );
            }
        }

        else
        {
            QMessageBox::information( this, "FrontEnd",
                                      "Error parsing emulator initialization file: check format" );

            delete _ini_file;
            _ini_file = NULL;
        }
    }
}

/////////////////////////////////////////////////////////////////////

void FrontEndWindow::close_emu( void )
{
	if ( ! _config_in_use )
		return;

	reset_control_text( );

	_list_box->clear( );

	QPixmap bitmap( DEFAULT_BITMAP );

    _pixmap->setPixmap( bitmap );

    if ( _ini_file  )
        delete _ini_file;
    
    if ( _dat_file  )
        delete _dat_file;

    _close_button->setEnabled ( false );
    _launch_button->setEnabled( false );

	_config_in_use = false;
}

/////////////////////////////////////////////////////////////////////

void FrontEndWindow::update_prog_controls( void )
{
	QString str;
	str = _list_box->currentText( );

	QString strBitmap = _dat_file->GetBitmapFromProgramName( str );
	
	if ( strBitmap.lower( ) == emu_dat_file::USE_DEFAULT_ENTRY_STRING )
		strBitmap = DEFAULT_BITMAP;

	else
	{
		strBitmap.sprintf( "%s%s", _ini_file->GetBitmapPath( ).latin1( ),
                            strBitmap.latin1( ) );
	}

	QPixmap bitmap( strBitmap );

    if ( bitmap.isNull( ) )
    {
        bitmap.load( DEFAULT_BITMAP );
    }

    _pixmap->setPixmap( bitmap );

    QString prog_text;
	prog_text.sprintf( "Info for %s :", str.latin1( ) );

	_prog_box->setTitle( prog_text );

	QString strText = _dat_file->GetTextFromProgramName( str );

	if ( strText.lower( ) == emu_dat_file::USE_DEFAULT_ENTRY_STRING )
		strText = "No Description";

	_prog_text->setText( strText );
}

/////////////////////////////////////////////////////////////////////

void FrontEndWindow::reset_control_text( void )
{
	_emu_box->setTitle ( "" );
	_emu_text->setText( "** no emulator config loaded **" );

	_prog_box->setTitle ( "" );
	_prog_text->setText( "** no program selected **" );

	_launch_button->setText( "&Launch" );
}

/////////////////////////////////////////////////////////////////////

void FrontEndWindow::on_launch_emu( void )
{
	QString str;
	str = _list_box->currentText( );

	if ( str == "" )		//  not sure if this could really happen
		return;

	//  TODO:  Check for / or \ separator etc
	
	QString bin_name =   _ini_file->GetProgramsPath( ) 
		               + _dat_file->GetBinaryFromProgramName( str );

	QString args = _dat_file->GetSpecialCommandArgsFromProgramName( str );

    if ( args == emu_dat_file::USE_DEFAULT_ENTRY_STRING )
	{
		args = _ini_file->GetDefaultCommandLine( );
	}

	QStringList tokens;

	parse_cmd_line( args, tokens );

	int num_args = tokens.count( );

    char** pARGS_PASSED_TO_EXEC_FUNC    = new char* [ num_args + 1 ];

    for ( int i = 0; i < num_args; i++ )
    {
        QStringList::Iterator it = tokens.at( i );

        QString cmd_arg = *it; 
        
        pARGS_PASSED_TO_EXEC_FUNC[ i ] = new char[ _MAX_PATH_ ];

        if ( cmd_arg == emu_dat_file::SYMBOLIC_FILE_ID )
        {
            strcpy( pARGS_PASSED_TO_EXEC_FUNC[ i ], bin_name );
        }

        else if ( cmd_arg == emu_dat_file::SYMBOLIC_FILE_ID_W_DELIM )
        {
            pARGS_PASSED_TO_EXEC_FUNC[ i ] [ 0 ] = _ini_file->GetCommandLineFlagDeliminter( );
            strcat( pARGS_PASSED_TO_EXEC_FUNC[ i ], bin_name );
        }

        else
        {
            strcpy( pARGS_PASSED_TO_EXEC_FUNC[ i ], cmd_arg.latin1( ) );
        }
    }

    pARGS_PASSED_TO_EXEC_FUNC[ num_args ] = NULL;

    int ret;

#ifdef _WS_WIN_
     ret = _spawnv( _P_NOWAIT, pARGS_PASSED_TO_EXEC_FUNC[ 0 ], pARGS_PASSED_TO_EXEC_FUNC );
#else
     ret = fork( );
#endif

    if ( -1 == ret )
       handle_spawn_error( pARGS_PASSED_TO_EXEC_FUNC[ 0 ] );

#ifndef _WS_WIN_

    else if( 0 == ret )
    {
        execv( pARGS_PASSED_TO_EXEC_FUNC[ 0 ], pARGS_PASSED_TO_EXEC_FUNC );

        //  If we get here there was a problem

        handle_spawn_error( pARGS_PASSED_TO_EXEC_FUNC[ 0 ] );
    }

#endif

    for ( int j = 0; j < num_args; j++ )
        delete [] pARGS_PASSED_TO_EXEC_FUNC[ j ];

    delete [] pARGS_PASSED_TO_EXEC_FUNC;
}

/////////////////////////////////////////////////////////////////////

void FrontEndWindow::parse_cmd_line( QString cmd_line, QStringList& tokenized_cmd_line )
{
	char* token = NULL;
	char delimiter[] = "%";         // field delimiter for command line
    char buf[ _MAX_PATH_ ];

    strcpy( buf, cmd_line.latin1( ) );

	token = strtok( buf, delimiter );

	do
	{
		if ( token && token[ 0 ] != 0xA && token[ 0 ] != 0xD && token[ 0 ] != ' ' )
		{
			tokenized_cmd_line.append( token );
		}

		token = strtok( NULL, delimiter );
    }
    while ( NULL != token );
}

/////////////////////////////////////////////////////////////////////

void FrontEndWindow::handle_spawn_error( QString prog_name )
{
    QString str = "FrontEnd: Launch error";
    QString str2;

    switch( errno )
    {
        case E2BIG:         str2 = "Argument list exceeds 1024 bytes\n " ; break;
        case EACCES:        str2 = "File has a sharing violation\n"     ; break;
        case EMFILE:        str2 = "Too many files open\n"              ; break;
        case ENOENT:        str2 = "File or path not found\n"           ; break;
        case ENOEXEC:       str2 = "Not executable or invalid format\n" ; break;
        case ENOMEM:        str2 = "Not enough memory\n"                ; break;
        default:            str2 = "Unknown error\n"                    ; break;
    }

    str2 += "Program: ";
    str2 += prog_name.latin1( );

    QMessageBox::information( this, str, str2 );
}
