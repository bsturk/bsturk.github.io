// emu_dat_file.cpp : implementation of the emu_dat_file class
//

#define _MAX_PATH_ 256

#include "emu_dat_file.h"

const QString emu_dat_file::SYMBOLIC_FILE_ID         =  "<file>";      // used as placeholder for 'rom'
const QString emu_dat_file::SYMBOLIC_FILE_ID_W_DELIM =  "<*file*>";    // used as placeholder rom using delimiter i.e. -foo.atr
const QString emu_dat_file::USE_DEFAULT_ENTRY_STRING = "default";
const QString emu_dat_file::DELIMITERS               = "$#";

const int emu_dat_file::BINARY_INDEX      = 2;
const int emu_dat_file::BITMAP_INDEX      = 3;
const int emu_dat_file::COMMAND_ARG_INDEX = 4;
const int emu_dat_file::TEXT_INDEX        = 5;
const int emu_dat_file::PAST_LAST_ENTRY   = 6;

emu_dat_file::emu_dat_file( const char* pszFileNameQualified )
{
    assert( pszFileNameQualified );

    m_strDatFileName = pszFileNameQualified;
}

/////////////////////////////////////////////////////////////////////

emu_dat_file::~emu_dat_file( )
{
}

/////////////////////////////////////////////////////////////////////

bool emu_dat_file::parse( void )
{
    FILE* fDatFile = fopen( m_strDatFileName, "r" ); 

    if ( !fDatFile )  
    {
        return false;
    }

    bool bComment, bValidLine;

    char line[ _MAX_PATH_ ];

    while ( fgets( line, _MAX_PATH_, fDatFile ) != NULL )
    {
        bValidLine = ParseLineForName( line, bComment );            
    }

    fclose( fDatFile );

    return true;
}

/////////////////////////////////////////////////////////////////////

bool emu_dat_file::ParseLineForName( char* textLine, bool& bComment )
{
    bComment             = false;
    char* token          = NULL;

    if ( textLine[ 0 ] != '$' ) 
    {
        bComment = true;
        return false;
    }

    /***** PROGRAM NAME ENTRY *****/

    token = strtok( textLine, DELIMITERS );

    //  BMS:TODO: 0xA is line feed (DOS), this may have to be different
    //  for other platforms...

    if ( NULL == token || token[ 0 ] == 0xA ) 
        return false;

    QString program_name = token;

    PROGRAM_NAMES.push_back ( program_name );

    return true;
}

/////////////////////////////////////////////////////////////////////

void emu_dat_file::GetProgramNames( std::vector< QString >& program_names, bool bSortIt) const
{
    program_names = PROGRAM_NAMES;

    if ( bSortIt )
    {
        SortVector( program_names );
    }
}

/////////////////////////////////////////////////////////////////////

void emu_dat_file::SortVector( std::vector< QString >& string_vector ) const
{
    int nNumEntries = string_vector.size( );

    QString temp;
    int i, j;

    for ( i = 0; i < nNumEntries; i++ )
        for ( j = 0; j < nNumEntries; j++ )
  
        //  Linux doesn't like the stricmp TODO
        //  if ( stricmp( string_vector[ i ], string_vector[ j ] ) < 0 )
        if ( strcmp( string_vector[ i ], string_vector[ j ] ) < 0 )
        {
            temp = string_vector[ i ];
    
            string_vector[ i ] = string_vector[ j ];
            string_vector[ j ] = temp;
        
        }
}

/////////////////////////////////////////////////////////////////////

QString emu_dat_file::GetBinaryFromProgramName( QString strProgramName ) const
{
    return GetTokenAtIndex( strProgramName, BINARY_INDEX );
}

/////////////////////////////////////////////////////////////////////

QString emu_dat_file::GetBitmapFromProgramName( QString strProgramName ) const
{
    return GetTokenAtIndex( strProgramName, BITMAP_INDEX );
}

/////////////////////////////////////////////////////////////////////

QString emu_dat_file::GetSpecialCommandArgsFromProgramName( QString strProgramName ) const
{
    return GetTokenAtIndex( strProgramName, COMMAND_ARG_INDEX );
}

/////////////////////////////////////////////////////////////////////

QString emu_dat_file::GetTextFromProgramName( QString strProgramName ) const
{
    return GetTokenAtIndex( strProgramName, TEXT_INDEX );
}

/////////////////////////////////////////////////////////////////////

QString emu_dat_file::GetTokenAtIndex( QString strProgramName, int nIndex ) const
{
    //  NOTE: Index is absolute

    assert( nIndex > 1 );                 //  clients shouldn't be asking for program name
    assert( nIndex < PAST_LAST_ENTRY );

    bool bSuccess = false;

    QString line = FindLineWithProgram( strProgramName, bSuccess );

    if ( !bSuccess )
    {
        return USE_DEFAULT_ENTRY_STRING;            //  TODO: Better handling
    }

    char* token          = NULL;

    //  make a copy of the line for strtok

    char buf[ _MAX_PATH_ ];
    strcpy( buf, line );

	//  skip first token which is program name

    token = strtok( buf, DELIMITERS );

    for ( int i = 1; i < nIndex; i++ )
    {
        token = strtok( NULL, DELIMITERS );

		//  no leading spaces or other whitspaceesque stuff
		
        if ( NULL == token || token[ 0 ] == 0xA  || token[ 0 ] == ' ' )
        {
            return USE_DEFAULT_ENTRY_STRING;
        }
    }

    return token;
}

/////////////////////////////////////////////////////////////////////

QString emu_dat_file::FindLineWithProgram( QString strProgramName, bool& bSuccess ) const
{

/*
    **********************************************************
    This routine will dig out a line that has a match in the first
    token placeholder ( 1st entry in the dat file ).  This test
    is case sensitive.  If there are duplicate entries the first
    match is the "winner".
    **********************************************************
*/

    bSuccess             = false;
    char* token          = NULL;
    char delimiters[]    = "$#";       

    FILE* fDatFile = fopen( m_strDatFileName, "r" ); 

    if ( !fDatFile )  
    {
        return "";
    }

    char line [ _MAX_PATH_ ];
    char saved[ _MAX_PATH_ ];

    while ( fgets( line, _MAX_PATH_, fDatFile ) != NULL )
    {
        if ( line[ 0 ] == '$' ) 
        {
			strcpy( saved, line );

            //  first token is program name

            token = strtok( line, delimiters );

            QString program_name = token;

            if ( strProgramName == program_name )
            {
                fclose( fDatFile );

                bSuccess = true;

                return saved;            //  implicit ctor w/ char*
            }
        }
    }

    fclose( fDatFile );

    return "";
}
