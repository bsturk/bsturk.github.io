*********************************  BootSelect ReadMe  *********************************

*** Operating system requirements ***
    
	Windows NT, 2000

***  Contact and License Info  ***

This program has no warranty.  
This program is free for non-profit use.
Blah, Blah, BLAH.

Actually it's giftware.  If you like/use/hate the program, I collect old 8 bit (Atari, C64, AppleII)
computer magazines and game company catalogs. Email me if you have anything interesting you're dying
to part with.

If you package this program up and distribute it
all I ask is that you let me know about it.

For questions, bug reports, feedback, etc:
bsturk@adelphia.net

Latest version always at:
http://users.adelphia.net/~bsturk
