*********************************  FrontEnd ReadMe  *********************************

Howdy emulator fans!  You have in your hands a simple, yet pretty flexible front end for 
emulators.  This front end is unlike most in that it doesn't cater to any particular flavor 
of emulators.  It can be customized to work with just about any emulator and runs on
many platforms.  All this without learning a batch macro language to use it.  :)

This front end boasts stuff like:

o   Human readable names for files with names like vidpnbll.bin.

o   Multiple program names can be associated with one physical file.  Useful for
    menu type images.  

o   Displaying of pictures corresponding to each rom/image.

o   Display text for each rom/image ( useful for controls of the game etc ).

o   Allows overriding of default command line arguments on a per rom/image basis.

o   The emulator's generic data files can be shared for the 6 different Atari 
    2600 emulators you use and also stored in one common directory if you want.  

o   Works with many if not all of the popular emulators.  If they accept command
    line parameters chances are it will.

o   Can run on any platform that the Qt class library has been ported to.

o   On Windows, no VB runtime stuff.  Yeeeechhhhh...
    
o   It's free!  ( see below )

***   Requirements   ***

Operating system requirements:
    
	Linux
	Windows 9x, ME, NT, 2000
	Mac OS X < not yet supported ( QT 3.0 ), I don't own it >

	FrontEnd is currently developed on Windows 2000 and Slackware Linux 7.1

** Windows **

    These files are all that you need to run FrontEnd.

		frontend.exe
		default.bmp
        qt-mt230nc.dll
        msvcrt.dll
        <emulator>.ini
        <emulator>.dat

    <emulator> can be any valid filename.

** Linux **

    NOTE: You must have at least QT 2.3.0 installed on your system for FrontEnd
          to run.  Please see www.trolltech.com, or see if your distribution has
          a Qt package you can install.

    The following files are the minimum ones that have to be in the same directory as 
    the program you are trying to run.

		frontend
		default.bmp
        <emulator>.ini
        <emulator>.dat

    <emulator> can be any valid filename.

    First "cd" into the directory you want to install.

    Run these commands to unpack the program:

        gunzip frontend.tar.gz
        tar xvf frontend.tar

    To compile from source code type "make" without the quotes in the directory
    you unpacked the src tarball.
    
***  File usage/importance  ***

The best thing to do is to use the included files as templates 
and whip out your favorite text editor to add new programs
or to modify the existing files ( Someday I'll add menus which
allow configuring via the GUI ).

-- ini file -- ( global settings for FrontEnd )

You open this file by choosing the "Open emu" buttonin FrontEnd.  The file
you downloaded should have contained an example ini file called "vss.ini".

Right now the locations of the lines are important.  The location of the entries
in each line is important also.  In the future I plan to make this a lot more 
relaxed and also allow changing these values from within FrontEnd.  

Here's an example that I use for Dan Boris's excellent Atari 5200 emu, 
Virtual Super System.

#%5200.EXE%<file>%-nostick%#        ***  The default command line ( see below )
#.\games\#                          ***  Path to roms etc ( can also be full drive/path combo )
#.\bitmaps\#                        ***  Path to bitmaps  ( can also be full drive/path combo )
#VSS#			                    ***  Name of the emulator/program
#-#                                 ***  Delimiter to use for rom/image/bin file if specified.
#Virtual Super System: Q to Quit#   ***  Information about this particular emulator

The default command line breaks down like this...

     1.       2.      3.
#%5200.exe%<file>%-nostick%#

1. The name of the executable.  Must be located in the same directory as the Frontend
   executable.  Must be be first.

2. <file>
   A symbolic link telling FrontEnd where to put the image/rom name.  Helps with the
   location problem that emulators front ends sometimes suffer from.  Use <*file*> to
   use the flag delimiter specified in the ini file.  If you use <*file*> and don't specify
   a delimiter in the ini file the default is the ever so common '-'.  The <file> can
   be anywhere in the command line.

3. a generic argument, you can use as many as you'd like ( up to 1024 bytes worth ).

-- programs "dat" file -- ( List of files to show in FrontEnd )

The file you downloaded should have contained an example dat file called "5200.dat".

Here's an example line...

 -----1------ ------2----- ------3------- -------------4---------- -----------5------------
$#Astro Chase#astrochs.bin#astrochase.bmp#%5200.exe%<file>%-debug%#Fast paced space shooter#

Valid lines begin with a '$'.  Any line without the '$' as the first
character of a line are treated as a comment.  There are then 5
fields that can be filled in.  Separate with # characters as shown above.   

1.  Name you want to show within FrontEnd list for a particular file/rom/binary file.

2.  The name of the actual file that corresponds to 1.  No path is needed.  The path given in
    the ini file is added to the file before launching the emulator/program.  If it's in a subdir
	of the path given in the ini file that'll work too.

3.  The screenshot you would like to show that corresponds to 1. See below
    for image formats supported.

4.  Custom arguments that override the default ones given in the ini file. 

5.  A text description of the game.  A good place to put hints about the controls, etc.

	Numbers 3, 4 and 5 above will resort to defaults if they're not present or if
    they are "default" or "DEFAULT".  So you could actually use FrontEnd with just
    the first 2, but it'd be kinda boring to look at.

***  Keyboard shortcuts  ***

a-z     With focus on "Available Programs" will scroll to the first entry with that
        letter either lower or upper case.  

Alt-L	Will launch the program/emu with whatever is selected in "Available Programs"
Alt-O	Will open the file selection dialog to open a FrontEnd "ini" file.
Alt-C	Will close the current emulator.

***  Known limitations  ***

The image formats supported are: PNG, BMP, XBM, XPM, PNM, GIF.

Some emulators seem to not be able to handle any of the following:

	Long pathnames to files.  i.e. bin, rom files, etc.  Both
	in length and adhering to the 8.3 format.  Some emulators seem to be
	pretty picky about em.

	Quotes around paths w/ spaces.

Before contacting me please ensure that the exact command line works manually.  
i.e. from command prompt.  On Windows if the emulator closes before you can
read it's diagnostic output try making a shortcut and unchecking the
"Close on Exit" box.

***  Contact and License Info  ***

This program has no warranty.  
This program is free for non-profit use.
Source code for this application is provided on the same web page as this readme file.
Blah, Blah, BLAH.  See the license.txt file in this package.

Actually it's giftware.  If you like/use/hate the program, I collect old 8 bit (Atari, C64, AppleII)
computer magazines and game company catalogs. Email me if you have anything interesting you're dying
to part with.

If you package this program up with an emulator bundle etc 
all I ask is that you let me know about it.

For questions, bug reports, feedback, etc:
bsturk@adelphia.net

Latest version always at:
http://users.adelphia.net/~bsturk
